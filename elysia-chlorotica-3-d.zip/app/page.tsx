"use client"

import { useState, useCallback, useEffect, useRef } from "react"
import dynamic from "next/dynamic"
import HUDOverlay from "@/components/ui/hud-overlay"
import SciencePanel from "@/components/ui/science-panel"
import IntroOverlay from "@/components/ui/intro-overlay"
import MobileJoystick from "@/components/ui/mobile-joystick"
import {
  createInitialState,
  updateSimulation,
  setLightIntensity,
  type SimulationState,
} from "@/lib/photosynthesis-model"

const SceneCanvas = dynamic(
  () => import("@/components/scene/scene-canvas"),
  { ssr: false }
)

export default function Page() {
  const [showIntro, setShowIntro] = useState(true)
  const [isInspecting, setIsInspecting] = useState(false)
  const [showPanel, setShowPanel] = useState(false)
  const [simulation, setSimulation] = useState<SimulationState>(createInitialState)
  const [isMobile, setIsMobile] = useState(false)
  const [moveInput, setMoveInput] = useState({ x: 0, y: 0 })
  const simulationRef = useRef(simulation)
  simulationRef.current = simulation

  // Mobil/tablet algilama
  useEffect(() => {
    const check = () => {
      setIsMobile(
        "ontouchstart" in window || navigator.maxTouchPoints > 0 || window.innerWidth < 768
      )
    }
    check()
    window.addEventListener("resize", check)
    return () => window.removeEventListener("resize", check)
  }, [])

  // Simulasyon dongusu
  useEffect(() => {
    const interval = setInterval(() => {
      setSimulation((prev) => updateSimulation(prev, 1))
    }, 500)
    return () => clearInterval(interval)
  }, [])

  const handleLightChange = useCallback((value: number) => {
    setSimulation((prev) => setLightIntensity(prev, value))
  }, [])

  const handleElysiaClick = useCallback(() => {
    setIsInspecting(true)
    setShowPanel(true)
  }, [])

  const handleToggleInspect = useCallback(() => {
    setIsInspecting((prev) => !prev)
    if (!isInspecting) {
      setShowPanel(true)
    }
  }, [isInspecting])

  const handleToggleInfo = useCallback(() => {
    setShowPanel((prev) => !prev)
  }, [])

  const handleDismissIntro = useCallback(() => {
    setShowIntro(false)
  }, [])

  const handleJoystickMove = useCallback((x: number, y: number) => {
    setMoveInput({ x, y })
  }, [])

  return (
    <main className="relative w-full h-screen select-none">
      <SceneCanvas
        lightIntensity={simulation.lightIntensity}
        chloroplastHealth={simulation.chloroplastHealth}
        isInspecting={isInspecting}
        showChloroplasts={isInspecting}
        onElysiaClick={handleElysiaClick}
        moveInput={moveInput}
      />

      {!showIntro && (
        <>
          <HUDOverlay
            depth={0.8}
            isInspecting={isInspecting}
            onToggleInspect={handleToggleInspect}
            onToggleInfo={handleToggleInfo}
            showInfo={showPanel}
            isMobile={isMobile}
          />

          <SciencePanel
            state={simulation}
            onLightChange={handleLightChange}
            onClose={() => setShowPanel(false)}
            isOpen={showPanel}
          />

          {isMobile && <MobileJoystick onMove={handleJoystickMove} />}
        </>
      )}

      {showIntro && <IntroOverlay onDismiss={handleDismissIntro} />}
    </main>
  )
}

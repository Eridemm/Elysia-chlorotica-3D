import type { Metadata, Viewport } from 'next'
import { Inter, Space_Mono } from 'next/font/google'

import './globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })
const spaceMono = Space_Mono({
  subsets: ['latin'],
  weight: ['400', '700'],
  variable: '--font-space-mono',
})

export const metadata: Metadata = {
  title: 'Elysia chlorotica - Etkilesimli Deniz Biyolojisi',
  description:
    'Gunes enerjisiyle calisan deniz sumuklu bocegi Elysia chlorotica\'yi suerukleyici bir 3B su alti ortaminda kesfedin. Kleptoplasti, fotosentez ve deniz biyolojisi hakkinda bilgi edinin.',
}

export const viewport: Viewport = {
  themeColor: '#071a14',
  userScalable: false,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="tr" className={`${inter.variable} ${spaceMono.variable}`}>
      <body className="font-sans antialiased overflow-hidden">{children}</body>
    </html>
  )
}

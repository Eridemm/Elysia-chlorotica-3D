/**
 * Photosynthesis simulation model for Elysia chlorotica
 *
 * Models:
 * - Light-dependent photosynthetic rate: P = Pmax * (I / (I + Km))
 *   where I is light intensity and Km is the half-saturation constant
 * - Energy storage: dE/dt = P - R (production minus respiration)
 * - Chloroplast degradation: C(t) = C0 * e^(-lambda * t)
 *   where lambda is the degradation rate constant
 */

export interface SimulationState {
  /** Current light intensity (0-1) */
  lightIntensity: number
  /** Chloroplast health/density (0-1) */
  chloroplastHealth: number
  /** Current energy production rate (arbitrary units) */
  energyProduction: number
  /** Stored energy level (0-100) */
  energyStored: number
  /** Basal metabolic consumption rate */
  respirationRate: number
  /** Time elapsed in simulation (hours) */
  timeElapsed: number
  /** Energy history for graphing */
  energyHistory: { time: number; energy: number; production: number }[]
}

// Constants
const P_MAX = 12 // Maximum photosynthetic rate (umol O2/mg chlorophyll/hr)
const K_M = 0.3 // Half-saturation constant for light
const RESPIRATION_RATE = 1.5 // Basal metabolic rate
const CHLOROPLAST_DEGRADATION_RATE = 0.001 // Lambda (per simulation tick)
const MAX_ENERGY = 100
const HISTORY_MAX_LENGTH = 60

export function createInitialState(): SimulationState {
  return {
    lightIntensity: 0.7,
    chloroplastHealth: 1.0,
    energyProduction: 0,
    energyStored: 60,
    respirationRate: RESPIRATION_RATE,
    timeElapsed: 0,
    energyHistory: [],
  }
}

/**
 * Michaelis-Menten-like light response curve
 * Models the saturating relationship between light intensity and photosynthetic rate
 */
function calculatePhotosynthesisRate(
  lightIntensity: number,
  chloroplastHealth: number
): number {
  if (lightIntensity <= 0 || chloroplastHealth <= 0) return 0
  return P_MAX * chloroplastHealth * (lightIntensity / (lightIntensity + K_M))
}

/**
 * Advance the simulation by one tick
 */
export function updateSimulation(
  state: SimulationState,
  deltaTime: number = 1
): SimulationState {
  const newTimeElapsed = state.timeElapsed + deltaTime

  // Chloroplast degradation (exponential decay)
  const newChloroplastHealth = Math.max(
    0,
    state.chloroplastHealth * Math.exp(-CHLOROPLAST_DEGRADATION_RATE * deltaTime)
  )

  // Photosynthetic energy production
  const photosynthesisRate = calculatePhotosynthesisRate(
    state.lightIntensity,
    newChloroplastHealth
  )

  // Net energy change: production minus respiration
  const netEnergyChange = (photosynthesisRate - RESPIRATION_RATE) * deltaTime * 0.5

  const newEnergyStored = Math.max(
    0,
    Math.min(MAX_ENERGY, state.energyStored + netEnergyChange)
  )

  // Update history
  const newHistoryEntry = {
    time: newTimeElapsed,
    energy: newEnergyStored,
    production: photosynthesisRate,
  }

  const newHistory = [...state.energyHistory, newHistoryEntry]
  if (newHistory.length > HISTORY_MAX_LENGTH) {
    newHistory.shift()
  }

  return {
    ...state,
    chloroplastHealth: newChloroplastHealth,
    energyProduction: photosynthesisRate,
    energyStored: newEnergyStored,
    respirationRate: RESPIRATION_RATE,
    timeElapsed: newTimeElapsed,
    energyHistory: newHistory,
  }
}

/**
 * Set the light intensity and return updated state
 */
export function setLightIntensity(
  state: SimulationState,
  intensity: number
): SimulationState {
  return {
    ...state,
    lightIntensity: Math.max(0, Math.min(1, intensity)),
  }
}

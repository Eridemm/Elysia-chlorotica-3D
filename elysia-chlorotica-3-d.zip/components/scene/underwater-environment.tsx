"use client"

import { useRef, useMemo } from "react"
import { useFrame } from "@react-three/fiber"
import * as THREE from "three"
import Fish3DSchool from "@/components/scene/fish-3d"

/* ────────────────────────────────────────────
   Water particles – suspended organic matter
   ──────────────────────────────────────────── */

function WaterParticles({ count = 300 }: { count?: number }) {
  const meshRef = useRef<THREE.InstancedMesh>(null)
  const dummy = useMemo(() => new THREE.Object3D(), [])

  const particles = useMemo(
    () =>
      Array.from({ length: count }, () => ({
        position: [
          (Math.random() - 0.5) * 16,
          Math.random() * 7 - 1,
          (Math.random() - 0.5) * 16,
        ] as [number, number, number],
        speed: Math.random() * 0.25 + 0.05,
        offset: Math.random() * Math.PI * 2,
        scale: Math.random() * 0.025 + 0.008,
      })),
    [count]
  )

  useFrame(({ clock }) => {
    if (!meshRef.current) return
    const t = clock.getElapsedTime()
    particles.forEach((p, i) => {
      dummy.position.set(
        p.position[0] + Math.sin(t * p.speed + p.offset) * 0.4,
        p.position[1] + Math.sin(t * p.speed * 0.5 + p.offset) * 0.2,
        p.position[2] + Math.cos(t * p.speed + p.offset) * 0.4
      )
      dummy.scale.setScalar(p.scale)
      dummy.updateMatrix()
      meshRef.current!.setMatrixAt(i, dummy.matrix)
    })
    meshRef.current.instanceMatrix.needsUpdate = true
  })

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
      <sphereGeometry args={[1, 6, 6]} />
      <meshStandardMaterial color="#d0e8c0" transparent opacity={0.45} roughness={1} />
    </instancedMesh>
  )
}

/* ────────────────────────────────────────────
   Caustic light rays from surface
   ──────────────────────────────────────────── */

function CausticRays() {
  const materialsRef = useRef<THREE.MeshStandardMaterial[]>([])

  const rays = useMemo(
    () =>
      Array.from({ length: 12 }, (_, i) => ({
        position: [
          (Math.random() - 0.5) * 14,
          5,
          (Math.random() - 0.5) * 14,
        ] as [number, number, number],
        rotation: [0, 0, (Math.random() - 0.5) * 0.3] as [number, number, number],
        scale: [Math.random() * 0.4 + 0.2, 10, Math.random() * 0.4 + 0.2] as [number, number, number],
        speed: Math.random() * 0.5 + 0.2,
        offset: (i / 12) * Math.PI * 2,
      })),
    []
  )

  useFrame(({ clock }) => {
    const t = clock.getElapsedTime()
    materialsRef.current.forEach((mat, i) => {
      const ray = rays[i]
      if (mat && ray) {
        mat.opacity = (Math.sin(t * ray.speed + ray.offset) * 0.5 + 0.5) * 0.12
      }
    })
  })

  return (
    <group>
      {rays.map((ray, i) => (
        <mesh key={i} position={ray.position} rotation={ray.rotation} scale={ray.scale}>
          <cylinderGeometry args={[0.08, 1.2, 1, 8]} />
          <meshStandardMaterial
            ref={(el) => {
              if (el) materialsRef.current[i] = el
            }}
            color="#aaeebb"
            transparent
            opacity={0.08}
            side={THREE.DoubleSide}
            depthWrite={false}
          />
        </mesh>
      ))}
    </group>
  )
}

/* ────────────────────────────────────────────
   Seabed floor with subtle bumps
   ──────────────────────────────────────────── */

function SeaFloor() {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.5, 0]} receiveShadow>
      <planeGeometry args={[24, 24, 48, 48]} />
      <meshStandardMaterial
        color="#4a5d3e"
        roughness={0.9}
        metalness={0.05}
        onBeforeCompile={(shader) => {
          shader.vertexShader = shader.vertexShader.replace(
            "#include <begin_vertex>",
            `
            vec3 transformed = vec3(position);
            float noise = sin(position.x * 2.5) * cos(position.y * 2.5) * 0.12 
                         + sin(position.x * 5.0 + 1.0) * cos(position.y * 4.0) * 0.04;
            transformed.z += noise;
            `
          )
        }}
      />
    </mesh>
  )
}

/* ────────────────────────────────────────────
   Boundary walls (invisible-ish)
   ──────────────────────────────────────────── */

function BoundaryWalls() {
  const size = 10
  const height = 8
  return (
    <group>
      {/* Front */}
      <mesh position={[0, height / 2 - 1.5, -size]} rotation={[0, 0, 0]}>
        <planeGeometry args={[size * 2, height]} />
        <meshStandardMaterial color="#1a3a28" transparent opacity={0.15} side={THREE.DoubleSide} />
      </mesh>
      {/* Back */}
      <mesh position={[0, height / 2 - 1.5, size]} rotation={[0, Math.PI, 0]}>
        <planeGeometry args={[size * 2, height]} />
        <meshStandardMaterial color="#1a3a28" transparent opacity={0.15} side={THREE.DoubleSide} />
      </mesh>
      {/* Left */}
      <mesh position={[-size, height / 2 - 1.5, 0]} rotation={[0, Math.PI / 2, 0]}>
        <planeGeometry args={[size * 2, height]} />
        <meshStandardMaterial color="#1a3a28" transparent opacity={0.15} side={THREE.DoubleSide} />
      </mesh>
      {/* Right */}
      <mesh position={[size, height / 2 - 1.5, 0]} rotation={[0, -Math.PI / 2, 0]}>
        <planeGeometry args={[size * 2, height]} />
        <meshStandardMaterial color="#1a3a28" transparent opacity={0.15} side={THREE.DoubleSide} />
      </mesh>
    </group>
  )
}

/* ────────────────────────────────────────────
   Algae strands – Vaucheria litorea
   ──────────────────────────────────────────── */

function AlgaeStrand({
  position,
  height,
  phase,
  color,
}: {
  position: [number, number, number]
  height: number
  phase: number
  color: string
}) {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame(({ clock }) => {
    if (!meshRef.current) return
    const t = clock.getElapsedTime()
    meshRef.current.rotation.x = Math.sin(t * 0.5 + phase) * 0.18
    meshRef.current.rotation.z = Math.cos(t * 0.3 + phase) * 0.12
  })

  return (
    <mesh ref={meshRef} position={position}>
      <cylinderGeometry args={[0.012, 0.025, height, 5]} />
      <meshStandardMaterial color={color} roughness={0.7} transparent opacity={0.85} />
    </mesh>
  )
}

function AlgaeStrands({ count = 55 }: { count?: number }) {
  const strands = useMemo(
    () =>
      Array.from({ length: count }, () => ({
        position: [
          (Math.random() - 0.5) * 16,
          -1.4,
          (Math.random() - 0.5) * 16,
        ] as [number, number, number],
        height: Math.random() * 1.8 + 0.4,
        phase: Math.random() * Math.PI * 2,
        color: `hsl(${100 + Math.random() * 40}, ${45 + Math.random() * 25}%, ${30 + Math.random() * 18}%)`,
      })),
    [count]
  )

  return (
    <group>
      {strands.map((s, i) => (
        <AlgaeStrand key={i} {...s} />
      ))}
    </group>
  )
}

/* ────────────────────────────────────────────
   Rocks and coral debris
   ──────────────────────────────────────────── */

function SeaFloorDebris() {
  const rocks = useMemo(
    () =>
      Array.from({ length: 25 }, () => ({
        position: [
          (Math.random() - 0.5) * 16,
          -1.3,
          (Math.random() - 0.5) * 16,
        ] as [number, number, number],
        scale: Math.random() * 0.18 + 0.05,
        rotation: [
          Math.random() * Math.PI,
          Math.random() * Math.PI,
          Math.random() * Math.PI,
        ] as [number, number, number],
        color: `hsl(${30 + Math.random() * 50}, ${12 + Math.random() * 15}%, ${25 + Math.random() * 18}%)`,
      })),
    []
  )

  return (
    <group>
      {rocks.map((rock, i) => (
        <mesh key={i} position={rock.position} scale={rock.scale} rotation={rock.rotation} castShadow>
          <dodecahedronGeometry args={[1, 0]} />
          <meshStandardMaterial color={rock.color} roughness={0.85} />
        </mesh>
      ))}
    </group>
  )
}

/* ── 3D Baliklar fish-3d.tsx dosyasindan import ediliyor ── */

/* ────────────────────────────────────────────
   Water surface shimmer above
   ──────────────────────────────────────────── */

function WaterSurface() {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame(({ clock }) => {
    if (!meshRef.current) return
    const t = clock.getElapsedTime()
    const geo = meshRef.current.geometry as THREE.PlaneGeometry
    const pos = geo.attributes.position
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i)
      const z = pos.getZ(i)
      pos.setY(
        i,
        Math.sin(x * 1.5 + t * 0.4) * 0.06 + Math.cos(z * 1.2 + t * 0.3) * 0.04
      )
    }
    pos.needsUpdate = true
    geo.computeVertexNormals()
  })

  return (
    <mesh ref={meshRef} rotation={[-Math.PI / 2, 0, 0]} position={[0, 6, 0]}>
      <planeGeometry args={[24, 24, 32, 32]} />
      <meshStandardMaterial
        color="#2a6a5a"
        transparent
        opacity={0.25}
        side={THREE.DoubleSide}
        roughness={0.15}
        metalness={0.4}
      />
    </mesh>
  )
}

/* ────────────────────────────────────────────
   Lighting – brighter, more examination-friendly
   ──────────────────────────────────────────── */

function UnderwaterLighting({ lightIntensity = 1 }: { lightIntensity: number }) {
  return (
    <>
      <fog attach="fog" args={["#0c2820", 4, 22]} />

      {/* Bright ambient for examination */}
      <ambientLight intensity={0.45} color="#6abf8a" />

      {/* Main directional – sun through water */}
      <directionalLight
        position={[3, 10, 2]}
        intensity={1.2}
        color="#a8e8b8"
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
      />

      {/* Fill lights for better organism visibility */}
      <pointLight position={[0, 4, 0]} intensity={0.6} color="#7ac89a" distance={14} />
      <pointLight position={[-4, 3, -3]} intensity={0.3} color="#5da87a" distance={12} />
      <pointLight position={[4, 2, 3]} intensity={0.25} color="#8abfaa" distance={10} />

      {/* Light intensity driven light */}
      <directionalLight
        position={[0, 12, 0]}
        intensity={lightIntensity * 0.7}
        color="#cceecc"
      />

      {/* Soft hemisphere light for overall fill */}
      <hemisphereLight
        args={["#88ccaa", "#2a4a3a", 0.4]}
      />
    </>
  )
}

/* ────────────────────────────────────────────
   Main environment composition
   ──────────────────────────────────────────── */

export default function UnderwaterEnvironment({ lightIntensity = 1 }: { lightIntensity?: number }) {
  return (
    <group>
      <UnderwaterLighting lightIntensity={lightIntensity} />
      <SeaFloor />
      <BoundaryWalls />
      <AlgaeStrands count={55} />
      <SeaFloorDebris />
      <WaterParticles count={300} />
      <CausticRays />
      <WaterSurface />
      <Fish3DSchool />
    </group>
  )
}

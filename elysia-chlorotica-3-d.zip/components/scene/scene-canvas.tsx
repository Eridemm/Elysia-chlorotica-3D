"use client"

import { Suspense, useRef, useEffect, useCallback } from "react"
import { Canvas, useFrame, useThree } from "@react-three/fiber"
import * as THREE from "three"
import UnderwaterEnvironment from "@/components/scene/underwater-environment"
import ElysiaChlorotica from "@/components/scene/elysia-chlorotica"

/* ──── WASD + Mouse/Touch Kamera Kontrolcusu ──── */

interface WASDControllerProps {
  isInspecting: boolean
  targetPosition: [number, number, number]
  moveInput: { x: number; y: number }
}

function WASDController({ isInspecting, targetPosition, moveInput }: WASDControllerProps) {
  const { camera, gl } = useThree()
  const keys = useRef<Record<string, boolean>>({})
  const euler = useRef(new THREE.Euler(0, 0, 0, "YXZ"))
  const isPointerDown = useRef(false)
  const prevPointer = useRef({ x: 0, y: 0 })
  const inspectLerp = useRef(new THREE.Vector3(0, 0.5, 4))

  // Sinirlar
  const BOUNDS = { minX: -8, maxX: 8, minY: -0.5, maxY: 5, minZ: -8, maxZ: 8 }
  const MOVE_SPEED = 2.5
  const LOOK_SPEED = 0.003

  // Klavye olaylari
  useEffect(() => {
    const onDown = (e: KeyboardEvent) => {
      keys.current[e.key.toLowerCase()] = true
    }
    const onUp = (e: KeyboardEvent) => {
      keys.current[e.key.toLowerCase()] = false
    }
    window.addEventListener("keydown", onDown)
    window.addEventListener("keyup", onUp)
    return () => {
      window.removeEventListener("keydown", onDown)
      window.removeEventListener("keyup", onUp)
    }
  }, [])

  // Mouse/Touch bakis kontrolu
  useEffect(() => {
    const dom = gl.domElement

    const onPointerDown = (e: PointerEvent) => {
      // Sadece sag tik veya iki parmak degil, tum pointer tipleri
      isPointerDown.current = true
      prevPointer.current = { x: e.clientX, y: e.clientY }
    }
    const onPointerUp = () => {
      isPointerDown.current = false
    }
    const onPointerMove = (e: PointerEvent) => {
      if (!isPointerDown.current) return
      const dx = e.clientX - prevPointer.current.x
      const dy = e.clientY - prevPointer.current.y
      prevPointer.current = { x: e.clientX, y: e.clientY }

      euler.current.setFromQuaternion(camera.quaternion)
      euler.current.y -= dx * LOOK_SPEED
      euler.current.x -= dy * LOOK_SPEED
      // Dikey bakis siniri
      euler.current.x = Math.max(-Math.PI / 3, Math.min(Math.PI / 3, euler.current.x))
      camera.quaternion.setFromEuler(euler.current)
    }

    dom.addEventListener("pointerdown", onPointerDown)
    dom.addEventListener("pointerup", onPointerUp)
    dom.addEventListener("pointermove", onPointerMove)
    dom.addEventListener("pointerleave", onPointerUp)

    return () => {
      dom.removeEventListener("pointerdown", onPointerDown)
      dom.removeEventListener("pointerup", onPointerUp)
      dom.removeEventListener("pointermove", onPointerMove)
      dom.removeEventListener("pointerleave", onPointerUp)
    }
  }, [camera, gl])

  useFrame((_, delta) => {
    if (isInspecting) {
      // Inceleme modunda canliyi yakindan goster
      inspectLerp.current.set(
        targetPosition[0],
        targetPosition[1] + 0.4,
        targetPosition[2] + 1.5
      )
      camera.position.lerp(inspectLerp.current, 0.03)
      const lookAt = new THREE.Vector3(...targetPosition)
      const dir = lookAt.sub(camera.position).normalize()
      const targetQ = new THREE.Quaternion().setFromUnitVectors(
        new THREE.Vector3(0, 0, -1),
        dir
      )
      camera.quaternion.slerp(targetQ, 0.03)
      return
    }

    // WASD hareket
    const forward = new THREE.Vector3()
    camera.getWorldDirection(forward)
    forward.y = 0
    forward.normalize()

    const right = new THREE.Vector3()
    right.crossVectors(forward, camera.up).normalize()

    const velocity = new THREE.Vector3()
    const k = keys.current
    const speed = MOVE_SPEED * delta

    // Klavye girisi
    if (k["w"] || k["arrowup"]) velocity.add(forward.clone().multiplyScalar(speed))
    if (k["s"] || k["arrowdown"]) velocity.add(forward.clone().multiplyScalar(-speed))
    if (k["a"] || k["arrowleft"]) velocity.add(right.clone().multiplyScalar(-speed))
    if (k["d"] || k["arrowright"]) velocity.add(right.clone().multiplyScalar(speed))
    if (k[" "]) velocity.y += speed // Yukari (bosluk)
    if (k["shift"]) velocity.y -= speed // Asagi

    // Mobil/tablet joystick girisi
    if (Math.abs(moveInput.x) > 0.05 || Math.abs(moveInput.y) > 0.05) {
      velocity.add(forward.clone().multiplyScalar(-moveInput.y * speed))
      velocity.add(right.clone().multiplyScalar(moveInput.x * speed))
    }

    // Yeni pozisyonu sinirla
    const newPos = camera.position.clone().add(velocity)
    newPos.x = THREE.MathUtils.clamp(newPos.x, BOUNDS.minX, BOUNDS.maxX)
    newPos.y = THREE.MathUtils.clamp(newPos.y, BOUNDS.minY, BOUNDS.maxY)
    newPos.z = THREE.MathUtils.clamp(newPos.z, BOUNDS.minZ, BOUNDS.maxZ)

    camera.position.copy(newPos)
  })

  return null
}

/* ──── Ana 3D Canvas ──── */

interface SceneCanvasProps {
  lightIntensity: number
  chloroplastHealth: number
  isInspecting: boolean
  showChloroplasts: boolean
  onElysiaClick: () => void
  moveInput: { x: number; y: number }
}

export default function SceneCanvas({
  lightIntensity,
  chloroplastHealth,
  isInspecting,
  showChloroplasts,
  onElysiaClick,
  moveInput,
}: SceneCanvasProps) {
  const elysiaPosition: [number, number, number] = [0, 0.2, 0]

  return (
    <Canvas
      shadows
      camera={{ position: [0, 0.5, 4], fov: 55, near: 0.1, far: 50 }}
      gl={{ antialias: true }}
      style={{ background: "#071a14" }}
      onCreated={({ gl: renderer }) => {
        renderer.toneMapping = THREE.ACESFilmicToneMapping
        renderer.toneMappingExposure = 1.1
      }}
    >
      <Suspense fallback={null}>
        <color attach="background" args={["#071a14"]} />

        <WASDController
          isInspecting={isInspecting}
          targetPosition={elysiaPosition}
          moveInput={moveInput}
        />

        <UnderwaterEnvironment lightIntensity={lightIntensity} />

        <ElysiaChlorotica
          position={elysiaPosition}
          onSelect={onElysiaClick}
          showChloroplasts={showChloroplasts}
          lightIntensity={lightIntensity}
          chloroplastHealth={chloroplastHealth}
        />
      </Suspense>
    </Canvas>
  )
}

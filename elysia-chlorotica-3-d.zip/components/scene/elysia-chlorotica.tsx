"use client"

import { useRef, useMemo, useState, useCallback } from "react"
import { useFrame } from "@react-three/fiber"
import * as THREE from "three"

/* ────────────────────────────────────────────
   Detailed leaf-shaped body with veins
   ──────────────────────────────────────────── */

function generateLeafShape(): THREE.Shape {
  const s = new THREE.Shape()
  // Ovate leaf outline – asymmetric like the real organism
  s.moveTo(0, -0.95)
  s.bezierCurveTo(0.15, -0.9, 0.42, -0.7, 0.55, -0.35)
  s.bezierCurveTo(0.62, -0.1, 0.6, 0.2, 0.52, 0.45)
  s.bezierCurveTo(0.42, 0.7, 0.25, 0.88, 0.1, 0.95)
  s.bezierCurveTo(0.03, 0.98, -0.03, 0.98, -0.1, 0.95)
  s.bezierCurveTo(-0.25, 0.88, -0.42, 0.7, -0.52, 0.45)
  s.bezierCurveTo(-0.6, 0.2, -0.62, -0.1, -0.55, -0.35)
  s.bezierCurveTo(-0.42, -0.7, -0.15, -0.9, 0, -0.95)
  return s
}

function generateBodyGeometry(): THREE.BufferGeometry {
  const shape = generateLeafShape()
  const geo = new THREE.ExtrudeGeometry(shape, {
    steps: 1,
    depth: 0.06,
    bevelEnabled: true,
    bevelThickness: 0.035,
    bevelSize: 0.03,
    bevelSegments: 6,
  })
  // Center
  geo.center()
  return geo
}

/* ────────────────────────────────────────────
   Leaf vein network – midrib + branching veins
   ──────────────────────────────────────────── */

function LeafVeins() {
  const veins = useMemo(() => {
    const curves: { points: THREE.Vector3[]; width: number }[] = []

    // Central midrib
    const midrib: THREE.Vector3[] = []
    for (let t = -0.85; t <= 0.85; t += 0.05) {
      midrib.push(new THREE.Vector3(Math.sin(t * 0.3) * 0.02, t, 0.065))
    }
    curves.push({ points: midrib, width: 0.012 })

    // Branching lateral veins from the midrib
    const branchCount = 14
    for (let i = 0; i < branchCount; i++) {
      const t = -0.7 + (i / (branchCount - 1)) * 1.5
      const side = i % 2 === 0 ? 1 : -1
      const angle = (0.35 + Math.random() * 0.2) * side
      const length = 0.25 + Math.random() * 0.2

      const pts: THREE.Vector3[] = []
      for (let s = 0; s <= 1; s += 0.15) {
        const x = Math.sin(t * 0.3) * 0.02 + s * Math.sin(angle) * length
        const y = t + s * Math.cos(angle) * length * 0.3
        const z = 0.065 + s * 0.005
        pts.push(new THREE.Vector3(x, y, z))
      }
      curves.push({ points: pts, width: 0.006 })

      // Secondary smaller veins
      if (Math.random() > 0.3) {
        const subPts: THREE.Vector3[] = []
        const startS = 0.4 + Math.random() * 0.3
        const subAngle = angle + (side * 0.3)
        const subLen = 0.08 + Math.random() * 0.08
        const baseX = Math.sin(t * 0.3) * 0.02 + startS * Math.sin(angle) * length
        const baseY = t + startS * Math.cos(angle) * length * 0.3
        for (let s = 0; s <= 1; s += 0.25) {
          subPts.push(new THREE.Vector3(
            baseX + s * Math.sin(subAngle) * subLen,
            baseY + s * Math.cos(subAngle) * subLen * 0.3,
            0.068
          ))
        }
        curves.push({ points: subPts, width: 0.003 })
      }
    }

    return curves
  }, [])

  return (
    <group>
      {veins.map((vein, i) => {
        const curve = new THREE.CatmullRomCurve3(vein.points)
        return (
          <mesh key={i}>
            <tubeGeometry args={[curve, 12, vein.width, 5, false]} />
            <meshStandardMaterial
              color="#a8e6b0"
              roughness={0.5}
              metalness={0.1}
              transparent
              opacity={0.85}
              emissive="#5aff8a"
              emissiveIntensity={0.15}
            />
          </mesh>
        )
      })}
    </group>
  )
}

/* ────────────────────────────────────────────
   Leaf edge – slightly lighter border
   ──────────────────────────────────────────── */

function LeafEdge() {
  const geo = useMemo(() => {
    const shape = generateLeafShape()
    const pts = shape.getPoints(80)
    const vecs = pts.map(p => new THREE.Vector3(p.x, p.y, 0.065))
    const curve = new THREE.CatmullRomCurve3(vecs, true)
    return new THREE.TubeGeometry(curve, 80, 0.008, 4, true)
  }, [])

  return (
    <mesh geometry={geo}>
      <meshStandardMaterial
        color="#7cdb90"
        roughness={0.4}
        transparent
        opacity={0.8}
        emissive="#5aff8a"
        emissiveIntensity={0.1}
      />
    </mesh>
  )
}

/* ────────────────────────────────────────────
   Sparkle / chloroplast particles on surface
   ──────────────────────────────────────────── */

function ChloroplastSparkles({ health }: { health: number }) {
  const meshRef = useRef<THREE.InstancedMesh>(null)
  const dummy = useMemo(() => new THREE.Object3D(), [])

  const particles = useMemo(() => {
    const leafShape = generateLeafShape()
    const pts: { x: number; y: number; phase: number; scale: number }[] = []
    // Scatter points inside the leaf shape
    for (let i = 0; i < 120; i++) {
      const x = (Math.random() - 0.5) * 1.1
      const y = (Math.random() - 0.5) * 1.8
      const p = new THREE.Vector2(x, y)
      // Simple inside-check: distance from center weighted by leaf shape
      const dx = x / 0.58
      const dy = y / 0.95
      if (dx * dx + dy * dy < 0.85) {
        pts.push({ x, y, phase: Math.random() * Math.PI * 2, scale: 0.004 + Math.random() * 0.006 })
      }
    }
    return pts
  }, [])

  useFrame(({ clock }) => {
    if (!meshRef.current) return
    const t = clock.getElapsedTime()
    particles.forEach((p, i) => {
      const twinkle = (Math.sin(t * 3 + p.phase) * 0.5 + 0.5) * health
      dummy.position.set(p.x, p.y, 0.07 + Math.sin(t * 2 + p.phase) * 0.003)
      dummy.scale.setScalar(p.scale * (0.6 + twinkle * 0.8))
      dummy.updateMatrix()
      meshRef.current!.setMatrixAt(i, dummy.matrix)
    })
    meshRef.current.instanceMatrix.needsUpdate = true
  })

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, particles.length]}>
      <sphereGeometry args={[1, 6, 6]} />
      <meshStandardMaterial
        color="#ccffcc"
        emissive="#88ffaa"
        emissiveIntensity={0.8 * health}
        transparent
        opacity={0.9 * health}
      />
    </instancedMesh>
  )
}

/* ────────────────────────────────────────────
   Parapodia – wing-like lateral extensions
   ──────────────────────────────────────────── */

function Parapodium({ side, phase }: { side: "left" | "right"; phase: number }) {
  const meshRef = useRef<THREE.Mesh>(null)
  const sign = side === "left" ? -1 : 1

  const geometry = useMemo(() => {
    const s = new THREE.Shape()
    s.moveTo(0, -0.5)
    s.bezierCurveTo(sign * 0.12, -0.35, sign * 0.32, -0.1, sign * 0.38, 0.2)
    s.bezierCurveTo(sign * 0.4, 0.4, sign * 0.3, 0.6, sign * 0.15, 0.65)
    s.bezierCurveTo(sign * 0.05, 0.68, 0, 0.5, 0, 0.35)
    s.lineTo(0, -0.5)
    return new THREE.ExtrudeGeometry(s, {
      steps: 1,
      depth: 0.015,
      bevelEnabled: true,
      bevelThickness: 0.01,
      bevelSize: 0.008,
      bevelSegments: 3,
    })
  }, [sign])

  useFrame(({ clock }) => {
    if (!meshRef.current) return
    const t = clock.getElapsedTime()
    // Cok yavas, ipeksi bir dalgalanma - balik yuzgeci degil, yaprak gibi
    meshRef.current.rotation.y = sign * (
      Math.sin(t * 0.25 + phase) * 0.15 +
      Math.cos(t * 0.12 + phase * 0.5) * 0.08 +
      0.12 // hafif dogal aciklik
    )
    meshRef.current.rotation.z = sign * Math.sin(t * 0.18 + phase) * 0.04
    meshRef.current.rotation.x = Math.sin(t * 0.15 + phase * 2) * 0.03
  })

  return (
    <mesh ref={meshRef} geometry={geometry} position={[0, 0.05, 0.03]}>
      <meshStandardMaterial
        color="#1f8a3e"
        roughness={0.55}
        metalness={0.05}
        transparent
        opacity={0.88}
        side={THREE.DoubleSide}
      />
    </mesh>
  )
}

/* ────────────────────────────────────────────
   Head with rhinophores + eyes
   ──────────────────────────────────────────── */

/* ────────────────────────────────────────────
   Salyangoz benzeri kafa - yaprak govdesinin
   disina cikan, belirgin boyun + bas + rhinofor
   ──────────────────────────────────────────── */

function Head() {
  const groupRef = useRef<THREE.Group>(null)
  const leftRhinoRef = useRef<THREE.Group>(null)
  const rightRhinoRef = useRef<THREE.Group>(null)
  const headRef = useRef<THREE.Group>(null)

  // Boyun geometrisi: yaprağın üstünden çıkan silindirimsi bağlantı
  const neckGeo = useMemo(() => {
    const path = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(0, 0.06, 0.02),
      new THREE.Vector3(0, 0.13, 0.05),
      new THREE.Vector3(0, 0.2, 0.08),
    ])
    return new THREE.TubeGeometry(path, 12, 0.055, 8, false)
  }, [])

  useFrame(({ clock }) => {
    const t = clock.getElapsedTime()
    // Kafa hafifce one-arkaya ve yana sallaniyor
    if (headRef.current) {
      headRef.current.rotation.x = Math.sin(t * 0.3 + 0.5) * 0.08
      headRef.current.rotation.z = Math.sin(t * 0.2) * 0.06
    }
    // Rhinoforlar: bagimsiz, yavas antensi hareket
    if (leftRhinoRef.current) {
      leftRhinoRef.current.rotation.x = -0.15 + Math.sin(t * 0.35 + 1) * 0.15
      leftRhinoRef.current.rotation.z = -0.3 + Math.sin(t * 0.25) * 0.08
    }
    if (rightRhinoRef.current) {
      rightRhinoRef.current.rotation.x = -0.15 + Math.sin(t * 0.35 - 1) * 0.15
      rightRhinoRef.current.rotation.z = 0.3 + Math.sin(t * 0.25 + 0.5) * 0.08
    }
  })

  const headMat = useMemo(
    () => ({
      color: "#3aaa55",
      roughness: 0.5,
      metalness: 0.06,
    }),
    []
  )

  return (
    <group ref={groupRef} position={[0, 0.82, 0.04]}>
      {/* ── Boyun: yaprağın üstünden dışarı çıkan bağlantı ── */}
      <mesh geometry={neckGeo}>
        <meshStandardMaterial {...headMat} />
      </mesh>

      {/* ── Ana kafa grubu (boyun ucunda) ── */}
      <group ref={headRef} position={[0, 0.2, 0.08]}>
        {/* Kafa: tek puruzsuz kuremsi - yuksek segment sayisi */}
        <mesh>
          <sphereGeometry args={[0.09, 32, 24]} />
          <meshStandardMaterial {...headMat} />
        </mesh>
        {/* Kafa alt-arka: boyunla birlesen kisim, yumusak gecis */}
        <mesh position={[0, -0.035, -0.01]}>
          <sphereGeometry args={[0.08, 24, 18]} />
          <meshStandardMaterial {...headMat} />
        </mesh>

        {/* Cok kucuk, seyrek beyaz puntikler (12 adet, minik) */}
        {useMemo(() => {
          const dots = []
          for (let i = 0; i < 12; i++) {
            const theta = Math.random() * Math.PI * 2
            const phi = Math.random() * Math.PI * 0.55
            const r = 0.092
            const x = r * Math.sin(phi) * Math.cos(theta)
            const y = r * Math.cos(phi) * 0.55 + 0.01
            const z = r * Math.sin(phi) * Math.sin(theta)
            if (z > -0.01) {
              dots.push(
                <mesh key={i} position={[x, y, z]}>
                  <sphereGeometry args={[0.0018, 4, 4]} />
                  <meshStandardMaterial
                    color="#eeffee"
                    emissive="#ccffdd"
                    emissiveIntensity={0.3}
                  />
                </mesh>
              )
            }
          }
          return dots
        }, [])}

        {/* ── Sol Rhinofor (geyik boynuzu gibi ayri cikiyor) ── */}
        <group ref={leftRhinoRef} position={[-0.045, 0.075, 0.01]}>
          {/* Kafadan ayri baslangic noktasi - belirgin bosluk */}
          {/* Ince uzun govde - kafaya degmiyor, yukari cikiyor */}
          <mesh position={[0, 0.04, 0]}>
            <cylinderGeometry args={[0.009, 0.016, 0.07, 10]} />
            <meshStandardMaterial color="#38a050" roughness={0.45} />
          </mesh>
          {/* Orta kisim */}
          <mesh position={[0, 0.095, 0]}>
            <cylinderGeometry args={[0.007, 0.009, 0.06, 8]} />
            <meshStandardMaterial color="#2f9045" roughness={0.45} />
          </mesh>
          {/* Uc - sivri koni */}
          <mesh position={[0, 0.14, 0]}>
            <coneGeometry args={[0.007, 0.09, 8]} />
            <meshStandardMaterial color="#258a38" roughness={0.4} />
          </mesh>
        </group>

        {/* ── Sag Rhinofor (geyik boynuzu gibi ayri cikiyor) ── */}
        <group ref={rightRhinoRef} position={[0.045, 0.075, 0.01]}>
          <mesh position={[0, 0.04, 0]}>
            <cylinderGeometry args={[0.009, 0.016, 0.07, 10]} />
            <meshStandardMaterial color="#38a050" roughness={0.45} />
          </mesh>
          <mesh position={[0, 0.095, 0]}>
            <cylinderGeometry args={[0.007, 0.009, 0.06, 8]} />
            <meshStandardMaterial color="#2f9045" roughness={0.45} />
          </mesh>
          <mesh position={[0, 0.14, 0]}>
            <coneGeometry args={[0.007, 0.09, 8]} />
            <meshStandardMaterial color="#258a38" roughness={0.4} />
          </mesh>
        </group>

        {/* ── Oral tentakuller: kafanin iki yaninda kucuk cikinti ── */}
        <mesh position={[-0.075, -0.015, 0.025]} rotation={[0.2, -0.4, -0.5]}>
          <coneGeometry args={[0.02, 0.06, 6]} />
          <meshStandardMaterial color="#3aaa55" roughness={0.5} transparent opacity={0.85} />
        </mesh>
        <mesh position={[0.075, -0.015, 0.025]} rotation={[0.2, 0.4, 0.5]}>
          <coneGeometry args={[0.02, 0.06, 6]} />
          <meshStandardMaterial color="#3aaa55" roughness={0.5} transparent opacity={0.85} />
        </mesh>
      </group>
    </group>
  )
}

/* ────────────────────────────────────────────
   Main Elysia chlorotica component
   ──────────────────────────────────────────── */

export interface ElysiaProps {
  position?: [number, number, number]
  onSelect?: () => void
  showChloroplasts?: boolean
  lightIntensity?: number
  chloroplastHealth?: number
}

export default function ElysiaChlorotica({
  position = [0, 0, 0],
  onSelect,
  showChloroplasts = false,
  lightIntensity = 1,
  chloroplastHealth = 1,
}: ElysiaProps) {
  const groupRef = useRef<THREE.Group>(null)
  const [hovered, setHovered] = useState(false)

  const bodyGeometry = useMemo(() => generateBodyGeometry(), [])

  const bodyColor = useMemo(() => {
    const healthy = new THREE.Color("#1a7a3a")
    const depleted = new THREE.Color("#6b5a3d")
    return healthy.clone().lerp(depleted, 1 - chloroplastHealth)
  }, [chloroplastHealth])

  const handlePointerOver = useCallback(() => {
    setHovered(true)
    document.body.style.cursor = "pointer"
  }, [])

  const handlePointerOut = useCallback(() => {
    setHovered(false)
    document.body.style.cursor = "default"
  }, [])

  /* ── Yaprak gibi suzulme hareketi ──
     Gercek Elysia chlorotica suda aktif olarak yuzmez;
     akintiya kapilmis bir yaprak gibi yavas ve zarif bir sekilde suzulur.
     Burada birden fazla dusuk frekanslı sinusu ustuste bindirerek
     dogal, kaotik gorunen bir suruklenmee olusturuyoruz. */
  useFrame(({ clock }) => {
    if (!groupRef.current) return
    const t = clock.getElapsedTime()

    // Yavas dikey suzulme: hafif asagi-yukari sallanma, yaprak gibi
    const driftY =
      Math.sin(t * 0.12) * 0.15 +          // ana yavas dalga
      Math.sin(t * 0.31 + 1.2) * 0.04 +    // ikincil titresim
      Math.cos(t * 0.07) * 0.06             // cok yavas yukselme-alcalma

    // Yatay suruklenmee: akinti etkisi, asimetrik
    const driftX =
      Math.sin(t * 0.09 + 0.5) * 0.12 +    // ana yatay akinti
      Math.cos(t * 0.23 + 2.0) * 0.03       // hafif titresim

    // Derinlik ekseni: cok hafif ileri-geri
    const driftZ =
      Math.sin(t * 0.14 + 3.0) * 0.04

    groupRef.current.position.x = position[0] + driftX
    groupRef.current.position.y = position[1] + driftY
    groupRef.current.position.z = position[2] + driftZ

    // Yaprak yuvarlanmasi: suyun icinde hafifce egiliyor, donuyor
    // Yavaş, zarifce yana yatma (bir yaprak rüzgarda döner gibi)
    groupRef.current.rotation.z =
      Math.sin(t * 0.15) * 0.1 +
      Math.cos(t * 0.08 + 1.0) * 0.06

    // Ön-arka eğilme: yavaşça burun kaldırıp indirme
    groupRef.current.rotation.x =
      Math.sin(t * 0.1 + 0.8) * 0.08 +
      Math.cos(t * 0.25) * 0.03

    // Çok yavaş kendi ekseni etrafında dönüş (akıntıda dönen yaprak)
    groupRef.current.rotation.y =
      Math.sin(t * 0.06) * 0.12
  })

  return (
    <group
      ref={groupRef}
      position={position}
      onClick={onSelect}
      onPointerOver={handlePointerOver}
      onPointerOut={handlePointerOut}
      scale={hovered ? 1.06 : 1}
    >
      {/* Main leaf body */}
      <mesh geometry={bodyGeometry} castShadow>
        <meshStandardMaterial
          color={bodyColor}
          roughness={0.45}
          metalness={0.08}
          transparent
          opacity={0.92}
          side={THREE.DoubleSide}
          emissive={bodyColor}
          emissiveIntensity={lightIntensity * 0.12}
        />
      </mesh>

      {/* Darker underside */}
      <mesh geometry={bodyGeometry} position={[0, 0, -0.01]}>
        <meshStandardMaterial
          color="#0e4420"
          roughness={0.7}
          transparent
          opacity={0.6}
          side={THREE.BackSide}
        />
      </mesh>

      {/* Leaf vein network */}
      <LeafVeins />

      {/* Leaf border highlight */}
      <LeafEdge />

      {/* Chloroplast sparkles */}
      <ChloroplastSparkles health={showChloroplasts ? chloroplastHealth : chloroplastHealth * 0.3} />

      {/* Parapodia */}
      <Parapodium side="left" phase={0} />
      <Parapodium side="right" phase={Math.PI * 0.3} />

      {/* Detailed head */}
      <Head />

      {/* Hover glow */}
      {hovered && (
        <pointLight position={[0, 0, 0.3]} intensity={0.4} color="#3dff7a" distance={2.5} />
      )}
    </group>
  )
}

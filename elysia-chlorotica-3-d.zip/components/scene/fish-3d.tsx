"use client"

import { useRef, useMemo } from "react"
import { useFrame } from "@react-three/fiber"
import * as THREE from "three"

/* ── Basit 3 boyutlu balik modeli ── */

function FishBody({
  bodyColor = "#e87030",
  finColor = "#d05020",
  scale = 1,
}: {
  bodyColor?: string
  finColor?: string
  scale?: number
}) {
  const tailRef = useRef<THREE.Mesh>(null)
  const topFinRef = useRef<THREE.Mesh>(null)

  useFrame(({ clock }) => {
    const t = clock.getElapsedTime()
    if (tailRef.current) {
      tailRef.current.rotation.y = Math.sin(t * 6) * 0.35
    }
    if (topFinRef.current) {
      topFinRef.current.rotation.z = Math.sin(t * 4 + 1) * 0.1
    }
  })

  return (
    <group scale={scale}>
      {/* Ana govde - uzun elipsoid */}
      <mesh>
        <sphereGeometry args={[0.18, 16, 12]} />
        <meshStandardMaterial color={bodyColor} roughness={0.35} metalness={0.15} />
      </mesh>
      {/* Govde on kisim - hafif sivri */}
      <mesh position={[0, 0, 0.14]}>
        <sphereGeometry args={[0.12, 12, 10]} />
        <meshStandardMaterial color={bodyColor} roughness={0.35} metalness={0.15} />
      </mesh>
      {/* Goz - sol */}
      <mesh position={[-0.1, 0.04, 0.18]}>
        <sphereGeometry args={[0.028, 8, 8]} />
        <meshStandardMaterial color="#111" roughness={0.2} metalness={0.5} />
      </mesh>
      {/* Goz parlama - sol */}
      <mesh position={[-0.105, 0.055, 0.2]}>
        <sphereGeometry args={[0.01, 6, 6]} />
        <meshStandardMaterial color="#fff" emissive="#fff" emissiveIntensity={0.5} />
      </mesh>
      {/* Goz - sag */}
      <mesh position={[0.1, 0.04, 0.18]}>
        <sphereGeometry args={[0.028, 8, 8]} />
        <meshStandardMaterial color="#111" roughness={0.2} metalness={0.5} />
      </mesh>
      {/* Goz parlama - sag */}
      <mesh position={[0.105, 0.055, 0.2]}>
        <sphereGeometry args={[0.01, 6, 6]} />
        <meshStandardMaterial color="#fff" emissive="#fff" emissiveIntensity={0.5} />
      </mesh>
      {/* Agiz */}
      <mesh position={[0, -0.02, 0.25]}>
        <sphereGeometry args={[0.03, 8, 4]} />
        <meshStandardMaterial color="#8b3010" roughness={0.7} />
      </mesh>
      {/* Kuyruk yuzgeci */}
      <mesh ref={tailRef} position={[0, 0, -0.22]}>
        <group>
          <mesh rotation={[0, 0.2, 0]}>
            <boxGeometry args={[0.01, 0.18, 0.14]} />
            <meshStandardMaterial
              color={finColor}
              roughness={0.4}
              transparent
              opacity={0.85}
              side={THREE.DoubleSide}
            />
          </mesh>
          <mesh rotation={[0, -0.2, 0]}>
            <boxGeometry args={[0.01, 0.18, 0.14]} />
            <meshStandardMaterial
              color={finColor}
              roughness={0.4}
              transparent
              opacity={0.85}
              side={THREE.DoubleSide}
            />
          </mesh>
        </group>
      </mesh>
      {/* Ust yuzgec */}
      <mesh ref={topFinRef} position={[0, 0.16, -0.02]} rotation={[0, 0, 0]}>
        <boxGeometry args={[0.008, 0.08, 0.16]} />
        <meshStandardMaterial
          color={finColor}
          roughness={0.4}
          transparent
          opacity={0.8}
          side={THREE.DoubleSide}
        />
      </mesh>
      {/* Yan yuzgecler */}
      <mesh position={[-0.15, -0.04, 0.06]} rotation={[0.3, 0, -0.5]}>
        <boxGeometry args={[0.08, 0.005, 0.05]} />
        <meshStandardMaterial color={finColor} roughness={0.4} transparent opacity={0.7} side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[0.15, -0.04, 0.06]} rotation={[0.3, 0, 0.5]}>
        <boxGeometry args={[0.08, 0.005, 0.05]} />
        <meshStandardMaterial color={finColor} roughness={0.4} transparent opacity={0.7} side={THREE.DoubleSide} />
      </mesh>
    </group>
  )
}

/* ── Tek bir yuzen balik ── */

interface SwimmingFishProps {
  startPos: [number, number, number]
  speed: number
  amplitude: number
  fishScale: number
  phase: number
  bodyColor: string
  finColor: string
}

function SwimmingFish({
  startPos,
  speed,
  amplitude,
  fishScale,
  phase,
  bodyColor,
  finColor,
}: SwimmingFishProps) {
  const groupRef = useRef<THREE.Group>(null)
  const prevPos = useRef(new THREE.Vector3(...startPos))
  const currentDir = useRef(new THREE.Vector3(1, 0, 0))

  useFrame(({ clock }) => {
    if (!groupRef.current) return
    const t = clock.getElapsedTime()

    const x = startPos[0] + Math.sin(t * speed + phase) * amplitude
    const y = startPos[1] + Math.sin(t * speed * 0.6 + phase * 1.5) * 0.25
    const z = startPos[2] + Math.cos(t * speed * 0.5 + phase) * amplitude * 0.5

    groupRef.current.position.set(x, y, z)

    // Hareket yonunu hesapla
    const newPos = new THREE.Vector3(x, y, z)
    const moveDir = newPos.clone().sub(prevPos.current)
    if (moveDir.length() > 0.0005) {
      moveDir.normalize()
      // Yumusak donus icin mevcut yonle karistir
      currentDir.current.lerp(moveDir, 0.04)
      currentDir.current.normalize()
    }
    prevPos.current.copy(newPos)

    // Baligin burnunu hareket yonune cevir
    // FishBody +Z yonune bakiyor, atan2 ile dogru aciyi buluyoruz
    const dir = currentDir.current
    groupRef.current.rotation.y = Math.atan2(dir.x, dir.z)
    // Hafif yukari-asagi egim
    groupRef.current.rotation.x = -Math.asin(THREE.MathUtils.clamp(dir.y, -0.5, 0.5)) * 0.5
    // Hafif yalpalama
    groupRef.current.rotation.z = Math.sin(t * speed * 2 + phase) * 0.06
  })

  return (
    <group ref={groupRef} position={startPos}>
      <FishBody bodyColor={bodyColor} finColor={finColor} scale={fishScale} />
    </group>
  )
}

/* ── Balik suruleri ── */

export default function Fish3DSchool() {
  const fishData = useMemo(
    () => [
      // Turuncu baliklar (kirmizi balik)
      { pos: [3, 1.5, -2] as [number, number, number], speed: 0.3, amp: 3, scale: 1.2, phase: 0, body: "#e87030", fin: "#d05020" },
      { pos: [-2, 2.2, -3] as [number, number, number], speed: 0.25, amp: 2.5, scale: 0.9, phase: 1.5, body: "#e88040", fin: "#cc5530" },
      { pos: [1, 0.8, 3] as [number, number, number], speed: 0.35, amp: 2, scale: 0.7, phase: 3.0, body: "#f09050", fin: "#e06030" },
      // Mavi tropikal baliklar
      { pos: [-3, 1.8, 1] as [number, number, number], speed: 0.28, amp: 3.5, scale: 1.0, phase: 0.8, body: "#3080cc", fin: "#2060aa" },
      { pos: [4, 2.5, -1] as [number, number, number], speed: 0.22, amp: 2.8, scale: 0.8, phase: 2.2, body: "#2870b8", fin: "#1a55a0" },
      // Gumus baliklar (kucuk, hizli)
      { pos: [-1, 1.2, -4] as [number, number, number], speed: 0.45, amp: 2, scale: 0.5, phase: 4.0, body: "#b0b8c0", fin: "#8898a8" },
      { pos: [2, 3.0, 2] as [number, number, number], speed: 0.4, amp: 2.2, scale: 0.45, phase: 5.0, body: "#a0aab5", fin: "#808a98" },
      { pos: [-4, 0.6, -2] as [number, number, number], speed: 0.5, amp: 1.8, scale: 0.4, phase: 1.0, body: "#b5bcc5", fin: "#9098a0" },
      // Sari-yesil baliklar
      { pos: [2, 1.0, -5] as [number, number, number], speed: 0.32, amp: 2.0, scale: 0.65, phase: 2.5, body: "#88b830", fin: "#6a9020" },
      { pos: [-3, 2.8, 4] as [number, number, number], speed: 0.27, amp: 2.6, scale: 0.75, phase: 3.8, body: "#90c038", fin: "#709828" },
    ],
    []
  )

  return (
    <group>
      {fishData.map((fish, i) => (
        <SwimmingFish
          key={i}
          startPos={fish.pos}
          speed={fish.speed}
          amplitude={fish.amp}
          fishScale={fish.scale}
          phase={fish.phase}
          bodyColor={fish.body}
          finColor={fish.fin}
        />
      ))}
    </group>
  )
}

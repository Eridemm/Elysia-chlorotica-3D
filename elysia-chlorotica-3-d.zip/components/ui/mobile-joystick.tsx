"use client"

import { useRef, useCallback, useEffect } from "react"

interface MobileJoystickProps {
  onMove: (x: number, y: number) => void
}

export default function MobileJoystick({ onMove }: MobileJoystickProps) {
  const outerRef = useRef<HTMLDivElement>(null)
  const innerRef = useRef<HTMLDivElement>(null)
  const activeTouch = useRef<number | null>(null)
  const centerRef = useRef({ x: 0, y: 0 })

  const RADIUS = 40

  const handleStart = useCallback(
    (e: React.TouchEvent) => {
      if (activeTouch.current !== null) return
      const touch = e.changedTouches[0]
      if (!touch || !outerRef.current) return
      activeTouch.current = touch.identifier
      const rect = outerRef.current.getBoundingClientRect()
      centerRef.current = {
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2,
      }
    },
    []
  )

  const handleMove = useCallback(
    (e: TouchEvent) => {
      if (activeTouch.current === null) return
      const touch = Array.from(e.changedTouches).find(
        (t) => t.identifier === activeTouch.current
      )
      if (!touch || !innerRef.current) return

      let dx = touch.clientX - centerRef.current.x
      let dy = touch.clientY - centerRef.current.y
      const dist = Math.sqrt(dx * dx + dy * dy)

      if (dist > RADIUS) {
        dx = (dx / dist) * RADIUS
        dy = (dy / dist) * RADIUS
      }

      innerRef.current.style.transform = `translate(${dx}px, ${dy}px)`
      onMove(dx / RADIUS, dy / RADIUS)
    },
    [onMove]
  )

  const handleEnd = useCallback(
    (e: TouchEvent) => {
      const touch = Array.from(e.changedTouches).find(
        (t) => t.identifier === activeTouch.current
      )
      if (!touch) return
      activeTouch.current = null
      if (innerRef.current) {
        innerRef.current.style.transform = "translate(0px, 0px)"
      }
      onMove(0, 0)
    },
    [onMove]
  )

  useEffect(() => {
    window.addEventListener("touchmove", handleMove, { passive: false })
    window.addEventListener("touchend", handleEnd)
    window.addEventListener("touchcancel", handleEnd)
    return () => {
      window.removeEventListener("touchmove", handleMove)
      window.removeEventListener("touchend", handleEnd)
      window.removeEventListener("touchcancel", handleEnd)
    }
  }, [handleMove, handleEnd])

  return (
    <div className="absolute bottom-24 left-8 z-50 touch-none">
      <div
        ref={outerRef}
        className="relative w-24 h-24 rounded-full bg-card/40 backdrop-blur border border-border/50 flex items-center justify-center"
        onTouchStart={handleStart}
        role="application"
        aria-label="Hareket joysticki"
      >
        <div
          ref={innerRef}
          className="w-10 h-10 rounded-full bg-primary/50 border-2 border-primary/70 transition-transform duration-75"
        />
        {/* Yonlendirme isaretleri */}
        <span className="absolute top-1 left-1/2 -translate-x-1/2 text-[8px] font-mono text-muted-foreground select-none">
          {"W"}
        </span>
        <span className="absolute bottom-1 left-1/2 -translate-x-1/2 text-[8px] font-mono text-muted-foreground select-none">
          {"S"}
        </span>
        <span className="absolute left-1 top-1/2 -translate-y-1/2 text-[8px] font-mono text-muted-foreground select-none">
          {"A"}
        </span>
        <span className="absolute right-1 top-1/2 -translate-y-1/2 text-[8px] font-mono text-muted-foreground select-none">
          {"D"}
        </span>
      </div>
    </div>
  )
}

"use client"

import { useState, useEffect } from "react"
import { Waves } from "lucide-react"

interface IntroOverlayProps {
  onDismiss: () => void
}

export default function IntroOverlay({ onDismiss }: IntroOverlayProps) {
  const [visible, setVisible] = useState(true)
  const [fading, setFading] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setFading(true)
      setTimeout(() => {
        setVisible(false)
        onDismiss()
      }, 800)
    }, 6000)
    return () => clearTimeout(timer)
  }, [onDismiss])

  const handleClick = () => {
    setFading(true)
    setTimeout(() => {
      setVisible(false)
      onDismiss()
    }, 500)
  }

  if (!visible) return null

  return (
    <div
      className={`absolute inset-0 z-[100] flex items-center justify-center transition-opacity duration-700 ${
        fading ? "opacity-0" : "opacity-100"
      }`}
      style={{
        background:
          "radial-gradient(ellipse at center, hsl(200 50% 5% / 0.95) 0%, hsl(200 50% 3% / 0.98) 100%)",
      }}
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === "Enter" && handleClick()}
      aria-label="Girisi kapat"
    >
      <div className="flex flex-col items-center gap-6 px-6 text-center max-w-md">
        <div className="relative">
          <Waves className="w-12 h-12 text-primary opacity-60" />
          <div className="absolute inset-0 w-12 h-12 rounded-full bg-primary/10 animate-ping" />
        </div>
        <div className="flex flex-col gap-2">
          <h1 className="text-2xl md:text-3xl font-sans font-bold text-foreground tracking-tight text-balance">
            Elysia chlorotica
          </h1>
          <p className="text-sm font-mono text-primary">
            {"Gunes Enerjisiyle Calisan Deniz Sumuklu Bocegi"}
          </p>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">
          {"Iliman Atlantik tuzlu bataklik gelgit havuzunu kesfedin ve bu olaganustu organizmanin fotosentez yapmak icin alglerden kloroplast calma yetenegini kesfedebilirsiniz."}
        </p>
        <div className="flex flex-col items-center gap-3 mt-2">
          <div className="bg-card/60 backdrop-blur border border-border/50 rounded-xl px-5 py-3">
            <p className="text-[10px] font-mono text-muted-foreground leading-relaxed">
              {"Bilgisayar: WASD hareket \u2022 Fare surukle: etrafina bak"}
            </p>
            <p className="text-[10px] font-mono text-muted-foreground leading-relaxed mt-1">
              {"Mobil: Joystick ile hareket \u2022 Dokunup surukle: etrafina bak"}
            </p>
          </div>
          <span className="text-[10px] font-mono text-muted-foreground animate-pulse">
            {"Dalmak icin herhangi bir yere tiklayin"}
          </span>
        </div>
      </div>
    </div>
  )
}

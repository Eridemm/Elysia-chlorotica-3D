"use client"

import { useEffect, useRef, useState } from "react"
import { Compass, Waves, Eye, Info, X, HelpCircle } from "lucide-react"

interface HUDOverlayProps {
  depth: number
  isInspecting: boolean
  onToggleInspect: () => void
  onToggleInfo: () => void
  showInfo: boolean
  isMobile: boolean
}

export default function HUDOverlay({
  depth,
  isInspecting,
  onToggleInspect,
  onToggleInfo,
  showInfo,
  isMobile,
}: HUDOverlayProps) {
  // Kontrol bilgi kutusu: program basinda otomatik acilir
  const [controlsOpen, setControlsOpen] = useState(true)
  const controlsRef = useRef<HTMLDivElement>(null)
  const buttonRef = useRef<HTMLButtonElement>(null)

  // Baska yere tiklaninca kapat
  useEffect(() => {
    if (!controlsOpen) return
    function handleClick(e: MouseEvent) {
      // Kutu icerisine veya butona tiklandiysa kapatma
      if (controlsRef.current?.contains(e.target as Node)) return
      if (buttonRef.current?.contains(e.target as Node)) return
      setControlsOpen(false)
    }
    // Bir sonraki tick'de dinlemeye basla (acilis tiklamasini yakalamasin)
    const timer = setTimeout(() => {
      document.addEventListener("click", handleClick)
    }, 100)
    return () => {
      clearTimeout(timer)
      document.removeEventListener("click", handleClick)
    }
  }, [controlsOpen])

  return (
    <>
      {/* Sol ust: Baslik ve konum */}
      <div className="absolute top-4 left-4 z-40 flex flex-col gap-2">
        <div className="bg-card/80 backdrop-blur-xl border border-border rounded-xl px-4 py-3">
          <h1 className="text-sm font-sans font-bold text-foreground tracking-tight">
            Elysia chlorotica
          </h1>
          <p className="text-[10px] font-mono text-primary mt-0.5">
            {"Tuzlu Batakl\u0131k Gelgit Havuzu \u2014 Atlantik K\u0131y\u0131s\u0131"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="bg-card/80 backdrop-blur-xl border border-border rounded-lg px-3 py-1.5 flex items-center gap-1.5">
            <Waves className="w-3 h-3 text-accent" />
            <span className="text-[10px] font-mono text-foreground">
              Derinlik: {depth.toFixed(1)}m
            </span>
          </div>
          <div className="bg-card/80 backdrop-blur-xl border border-border rounded-lg px-3 py-1.5 flex items-center gap-1.5">
            <Compass className="w-3 h-3 text-muted-foreground" />
            <span className="text-[10px] font-mono text-muted-foreground">
              {"Serbest Gezinti"}
            </span>
          </div>
        </div>
      </div>

      {/* Alt orta: Kontroller */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-40 flex items-center gap-2">
        <button
          onClick={onToggleInspect}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl border backdrop-blur-xl transition-all ${
            isInspecting
              ? "bg-primary/20 border-primary text-primary"
              : "bg-card/80 border-border text-foreground hover:bg-secondary"
          }`}
          aria-label={isInspecting ? "Inceleme modundan cik" : "Inceleme moduna gir"}
        >
          <Eye className="w-4 h-4" />
          <span className="text-xs font-mono">
            {isInspecting ? "Inceleniyor" : "Canl\u0131y\u0131 Incele"}
          </span>
        </button>
        <button
          onClick={onToggleInfo}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl border backdrop-blur-xl transition-all ${
            showInfo
              ? "bg-primary/20 border-primary text-primary"
              : "bg-card/80 border-border text-foreground hover:bg-secondary"
          }`}
          aria-label={showInfo ? "Bilim panelini kapat" : "Bilim panelini ac"}
        >
          <Info className="w-4 h-4" />
          <span className="text-xs font-mono">
            {showInfo ? "Veriyi Gizle" : "Bilim Paneli"}
          </span>
        </button>
      </div>

      {/* Sag alt: Kontrol bilgi kutusu veya kucuk logo */}
      <div className="absolute bottom-4 right-4 z-50">
        {controlsOpen ? (
          <div
            ref={controlsRef}
            className="bg-card/90 backdrop-blur-xl border border-primary/30 rounded-xl p-4 max-w-72 shadow-lg shadow-primary/5 animate-in fade-in slide-in-from-bottom-2 duration-300"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-primary" />
                <span className="text-xs font-sans font-bold text-foreground">
                  Kontroller
                </span>
              </div>
              <button
                onClick={() => setControlsOpen(false)}
                className="text-muted-foreground hover:text-foreground transition-colors"
                aria-label="Kapat"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            {isMobile ? (
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <span className="text-primary font-mono text-[10px] bg-primary/10 rounded px-1.5 py-0.5 shrink-0">
                    Joystick
                  </span>
                  <span className="text-[11px] font-mono text-muted-foreground leading-relaxed">
                    {"Sol alttaki joystick ile hareket et"}
                  </span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-primary font-mono text-[10px] bg-primary/10 rounded px-1.5 py-0.5 shrink-0">
                    {"Dokun + S\u00fcr\u00fckle"}
                  </span>
                  <span className="text-[11px] font-mono text-muted-foreground leading-relaxed">
                    {"Ekrana dokunup s\u00fcr\u00fckleyerek etraf\u0131na bak"}
                  </span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-primary font-mono text-[10px] bg-primary/10 rounded px-1.5 py-0.5 shrink-0">
                    Dokun
                  </span>
                  <span className="text-[11px] font-mono text-muted-foreground leading-relaxed">
                    {"Canl\u0131ya dokunarak inceleme moduna ge\u00e7"}
                  </span>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <div className="flex gap-0.5 shrink-0">
                    {["W", "A", "S", "D"].map((k) => (
                      <span
                        key={k}
                        className="text-primary font-mono text-[10px] bg-primary/10 border border-primary/20 rounded w-5 h-5 flex items-center justify-center"
                      >
                        {k}
                      </span>
                    ))}
                  </div>
                  <span className="text-[11px] font-mono text-muted-foreground leading-relaxed">
                    {"Hareket et (ileri, sola, geri, sa\u011fa)"}
                  </span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-primary font-mono text-[10px] bg-primary/10 border border-primary/20 rounded px-1.5 py-0.5 shrink-0">
                    Fare
                  </span>
                  <span className="text-[11px] font-mono text-muted-foreground leading-relaxed">
                    {"Bas\u0131l\u0131 tut + s\u00fcr\u00fckle ile etraf\u0131na bak"}
                  </span>
                </div>
                <div className="flex items-start gap-2">
                  <div className="flex gap-0.5 shrink-0">
                    <span className="text-primary font-mono text-[10px] bg-primary/10 border border-primary/20 rounded px-1 py-0.5">
                      {"Bo\u015fluk"}
                    </span>
                    <span className="text-primary font-mono text-[10px] bg-primary/10 border border-primary/20 rounded px-1 py-0.5">
                      Shift
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-muted-foreground leading-relaxed">
                    {"Yukar\u0131 / a\u015fa\u011f\u0131 hareket"}
                  </span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-primary font-mono text-[10px] bg-primary/10 border border-primary/20 rounded px-1.5 py-0.5 shrink-0">
                    {"T\u0131kla"}
                  </span>
                  <span className="text-[11px] font-mono text-muted-foreground leading-relaxed">
                    {"Canl\u0131ya t\u0131klayarak inceleme moduna ge\u00e7"}
                  </span>
                </div>
              </div>
            )}
            <p className="text-[9px] text-muted-foreground/60 mt-3 font-mono">
              {"Ba\u015fka bir yere t\u0131klayarak bu kutuyu kapatabilirsiniz"}
            </p>
          </div>
        ) : (
          <button
            ref={buttonRef}
            onClick={() => setControlsOpen(true)}
            className="bg-card/80 backdrop-blur-xl border border-border hover:border-primary/50 rounded-xl p-2.5 transition-all hover:bg-secondary group"
            aria-label="Kontrolleri goster"
          >
            <HelpCircle className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
          </button>
        )}
      </div>

      {/* Vinyet efekti */}
      <div
        className="absolute inset-0 pointer-events-none z-30"
        style={{
          background:
            "radial-gradient(ellipse at center, transparent 55%, rgba(7, 26, 20, 0.5) 100%)",
        }}
      />

      {/* Tarama cizgisi efekti */}
      <div
        className="absolute inset-0 pointer-events-none z-30 opacity-[0.02]"
        style={{
          backgroundImage:
            "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(100, 200, 150, 0.1) 2px, rgba(100, 200, 150, 0.1) 4px)",
        }}
      />
    </>
  )
}
